"""
Version and authorship information
"""
__author__    = 'Jason Anthony Vander Heiden'
__copyright__ = 'Copyright 2013 Kleinstein Lab, Yale University. All rights reserved.'
__license__   = 'Creative Commons Attribution-NonCommercial-ShareAlike 4.0 Unported'
__version__   = '0.5.2'
__date__      = '2016.03.08'
